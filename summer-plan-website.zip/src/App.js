import React from 'react';
import Plan from './Plan';

function App() {
  return (
    <div className="App">
      <Plan />
    </div>
  );
}

export default App;